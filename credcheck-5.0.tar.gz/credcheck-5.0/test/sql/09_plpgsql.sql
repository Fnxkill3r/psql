LOAD 'credcheck';

SET credcheck.password_valid_until TO 4;
SET credcheck.password_valid_max TO 0;
DO $$
BEGIN
	CREATE ROLE test10 LOGIN PASSWORD '101!!010101010abc!' NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE NOREPLICATION;
END
$$;
select 1 from pg_shadow where usename = 'test10' and valuntil IS NOT NULL;

DROP ROLE test10;


