/*
 * src/include/port/unixware.h
 *
 * see src/backend/libpq/pqcomm.c */
#define SCO_ACCEPT_BUG

/***************************************
 * Define this if you are compiling with
 * the native UNIXWARE C compiler.
 ***************************************/
#define USE_UNIVEL_CC
