-- credcheck extension for PostgreSQL
-- Copyright (c) 2024-2026 HexaCluster Corp - All rights reserved.

-- Nothing to do, only library change
