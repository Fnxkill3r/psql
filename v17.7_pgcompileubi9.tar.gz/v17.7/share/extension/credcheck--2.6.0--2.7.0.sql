-- credcheck extension for PostgreSQL
-- Copyright (c) 2024 HexaCluster Corp - All rights reserved.

-- No SQL change to apply in this version

