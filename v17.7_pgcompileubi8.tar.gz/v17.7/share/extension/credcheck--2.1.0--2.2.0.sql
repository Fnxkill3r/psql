-- credcheck extension for PostgreSQL
-- Copyright (c) 2021-2023 MigOps Inc - All rights reserved.
-- Copyright (c) 2023 Gilles Darold - All rights reserved.

-- No SQL change to apply in this version

